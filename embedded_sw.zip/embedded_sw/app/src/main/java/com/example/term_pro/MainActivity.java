package com.example.term_pro;

import java.util.*;

import android.app.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;



public class MainActivity extends Activity {

    public int action;
    public int direction;
    private int arrImage[] =   {0, 0, 0};     // 가위 바위보  이미지
    private int arrScore[] =   {0, 0, 0};     // 화면 상단 점수
    private int arrSResult[] = {0, 0, 0};     // 승패 표시용 (비김, 이김, 짐)
    private int arrButton[] = {0, 0, 0, 0};      // 버튼 Text

    private int TitleColor = 0xFFFFFF00;          // 제목줄 글자 색깔 - ARGB
    private int _counter = 0;             // 제목줄 글자 색깔 지연 카운터
    private boolean _isRun = true;         // 타이머가 가동중인가?

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.Button01).setOnClickListener(MyButtonListener);
        findViewById(R.id.Button02).setOnClickListener(MyButtonListener);
        findViewById(R.id.Button03).setOnClickListener(MyButtonListener);


        InitGame();  // 게임 초기화
        mHandler.sendEmptyMessageDelayed(0, 300);
    } // onCreate

    // ----------------------------------------
    //        게임 초기화  - 변수 설정 등
    // ----------------------------------------
    public void InitGame() {
        arrImage[0] = R.drawable.img_1;       // 가위
        arrImage[1] = R.drawable.img_2;       // 바위
        arrImage[2] = R.drawable.img_3;       // 보

        arrSResult[0] = R.string.strResult0;   // 비김
        arrSResult[1] = R.string.strResult1;   // 이김
        arrSResult[2] = R.string.strResult2;   // 짐

        arrButton[0] = R.string.strButton2;
        arrButton[1] = R.string.strButton3;
        arrButton[2] = R.string.strButton4;
        arrButton[3] = R.string.strButton5;

        ((TextView) findViewById(R.id.txtResult)).setText(""); // 맨 아래 승부 표시 지움
    } // InitGame

    // ----------------------------------------
    //         Button.OnClickListener
    // ----------------------------------------
    Button.OnClickListener MyButtonListener = new Button.OnClickListener() {
        public void onClick(View v) {
            int you = Integer.parseInt(v.getTag().toString());           // 버튼의 Tag 읽기
            if (_isRun == true) {                                                // 게임이 진행중이면
                int phone = new Random().nextInt(3);                   //   난수 발생하고
                _isRun = false;                                                 //   타이머 중지
                SetButtons(false);                                            //   [시작]/[게임끝] 보이도록
                PanJung(you, phone);
            } else {                                                               // [시작]/[게임끝] 중하나를 눌렀을 때
                if (you == 1) {                                                 // [시작] 버튼이면
                    SetButtons(true);                                   //   버튼을 [가위/바위/보] 상태로 바꾸고
                    ReceiveTextLcdValue("", "");                             //TextLcd 초기화
                    _isRun = true;                                             //   타이머를 기동하도록 하고
                    mHandler.sendEmptyMessageDelayed(0, 0);     //   타이머 호출
                }  else {                                                         // [게임끝] 버튼이면
                    finish();//   프로그램 종료
                    ReceiveTextLcdValue("", "");                                 //TextLcd 초기화
                    return;
                }
            } // if
        }
    }; // OnClickListener

    // ----------------------------------------
    //           버튼 감추기 / 보이기
    // ----------------------------------------
    void SetButtons(boolean flag) {
        if (flag == false) {  // [가위] 버튼 감추기
            ((Button) findViewById(R.id.Button01)).setVisibility(View.INVISIBLE);
            ((Button) findViewById(R.id.Button02)).setText(arrButton[2]);
            ((Button) findViewById(R.id.Button03)).setText(arrButton[3]);

            // 프로그램 제목 다시 표시 (혹시 안보이는 상태일 수도 있으니까)
            TitleColor = 0xFFFFFF00;
            ((TextView) findViewById(R.id.txtTitle)).setTextColor(TitleColor);

        } else {     // [가위] 버튼 보이기
            ((Button) findViewById(R.id.Button01)).setVisibility(View.VISIBLE);
            ((Button) findViewById(R.id.Button02)).setText(arrButton[0]);
            ((Button) findViewById(R.id.Button03)).setText(arrButton[1]);
            ((TextView) findViewById(R.id.txtResult)).setText(""); // 맨 아래 승부 표시 지움
        }
    }

    // ----------------------------------------
    //       승부 판정
    // ----------------------------------------
    void PanJung(int you, int phone) {
        int result;
        int speed = 5;

        if (you == phone) result = 0;                                                  // 비김
        else if (you - phone == 1 || you - phone == -2) result = 1;         // 이김
        else result = 2;                                                                     // 짐

        if (result != 0) arrScore[result]++;     // 승패 기록
        arrScore[0]++;                             // 전체 게임 수

        Display(you, phone, result);

if (result == 0) {
    ReceiveTextLcdValue("      Draw", "      GGa b");
    SetMotorState(action,direction,speed);
    ReceiveBuzzerValue(1);

    Handler mHandler = new Handler();
    mHandler.postDelayed(new Runnable() {
        @Override
        public void run() {

            SetMotorState(action = 0, direction = 0, speed);
            ReceiveBuzzerValue(0);

        }
    },2000);

}
        else if (result == 1) {
    ReceiveTextLcdValue("    !!Win!!", "!!!feel good!!!");
    SetMotorState(action = 1 , direction = 0 ,speed);
    ReceiveBuzzerValue(1);

    Handler mHandler = new Handler();
    mHandler.postDelayed(new Runnable() {
        @Override
        public void run() {
            SetMotorState(action = 0, direction = 0, speed);
        }
    },150);

    mHandler.postDelayed(new Runnable() {
        @Override
        public void run() {
            SetMotorState(action = 1, direction = 1, speed);
            ReceiveBuzzerValue(0);
        }
    },2000);

    mHandler.postDelayed(new Runnable() {
        @Override
        public void run() {
            SetMotorState(action = 0, direction = 0, speed);
        }
    },2150);
}

 if (result == 2) {
    ReceiveTextLcdValue("     Lose...", "   next time...");
    SetMotorState(action = 1 , direction = 1 ,speed);
    ReceiveBuzzerValue(1);

     Handler mHandler = new Handler();
     mHandler.postDelayed(new Runnable() {
         @Override
         public void run() {
             SetMotorState(action = 0, direction = 0, speed);
         }
     },150);

     mHandler.postDelayed(new Runnable() {
         @Override
         public void run() {
             SetMotorState(action = 1, direction = 0, speed);
             ReceiveBuzzerValue(0);
         }
     },2000);

     mHandler.postDelayed(new Runnable() {
         @Override
         public void run() {
             SetMotorState(action = 0, direction = 0, speed);
         }
     },2150);

}
    }

    // 판정

    // ----------------------------------------
    //      점수, 가위 바위 보 이미지 표시
    // ----------------------------------------
    void Display(int you, int phone, int result) {
        MakeReverse(arrImage[you]);   // 이미지 뒤집기
        // phone 이미지 표시
        ((ImageView) findViewById(R.id.ImageView02)).setImageResource(arrImage[phone]);

        // 승패 표시
        ((TextView) findViewById(R.id.txtResult)).setText(arrSResult[result]);

        // 상단 점수 표시
        ((TextView) findViewById(R.id.scrYou)).setText(" " + arrScore[1]);
        ((TextView) findViewById(R.id.scrPhone)).setText(" " + arrScore[2]);               // 알파
        ((TextView) findViewById(R.id.scrTot)).setText(" " + arrScore[0]);                   // total
    }// Display


    // ----------------------------------------
    //      이미지 뒤집기
    // ----------------------------------------
    void MakeReverse(int id) {
        Bitmap bitmap, reverse;
        Matrix matrix = new Matrix();
        matrix.postScale(-1, 1);     // y축 대칭

        bitmap = BitmapFactory.decodeResource(getResources(), id);
        int w = bitmap.getWidth();
        int h = bitmap.getHeight();
        reverse = Bitmap.createBitmap(bitmap, 0, 0, w, h, matrix, false);
        ((ImageView) findViewById(R.id.ImageView01)).setImageBitmap(reverse);
    } // Make...

    // ----------------------------------------
    //    제목 깜박거림, 이미지 랜덤 표시
    // ----------------------------------------
    public void DrawBlink() {
        Random rnd = new Random();
        int n1 = _counter % 3;
        int n2 = rnd.nextInt(3);

        _counter++;
        if (_counter % 2 == 1) {      // 글자는 이미지 절만의 주기로 깜박거림
            TitleColor = 0xFF0000FF - TitleColor;
            ((TextView) findViewById(R.id.txtTitle)).setTextColor(TitleColor);
        }
        MakeReverse(arrImage[n1]);  // 이미지 뒤집기
        ((ImageView) findViewById(R.id.ImageView02)).setImageResource(arrImage[n2]);
    } // DrawBlink

    // ----------------------------------------
    //          타이머 핸들러
    // ----------------------------------------
    Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            if (_isRun == false) return;
            DrawBlink();
            mHandler.sendEmptyMessageDelayed(0, 300);
        }
    };  // Handler

    public native int ReceiveTextLcdValue(String ptr1,String ptr2);
    public native int ReceiveBuzzerValue(int x);
    public native String SetMotorState(int x, int y, int z);

    static {
        System.loadLibrary("native-lib");
    }
}  // 프로그램 끝